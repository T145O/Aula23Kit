package br.com.starlog.controller;

import br.com.starlog.model.CriptoMensagem;
import java.util.ArrayList;
import java.util.List;

/**
 * CAMADA CONTROLLER (O Maestro da Transmissão)
 */
public class TransmissaoController {

    private final List<String> bufferTransmissoes = new ArrayList<>();

    /**
     * Orquestra a transmissão da mensagem.
     * 
     * @param remetenteRaw Remetente vindo do campo de texto da tela
     * @param msgRaw       Mensagem vinda do campo de texto da tela
     * @param chaveStr     Chave digitada como texto na tela
     * @return Pacote formatado no padrão: [REMETENTE] #CHECKSUM -> TEXTO_CIFRADO
     */
    public String processarTransmissao(String remetenteRaw, String msgRaw, String chaveStr) {
        // 1. Converter chaveStr para inteiro com tratamento seguro de exceções
        int deslocamento;
        try {
            if (chaveStr == null) {
                throw new IllegalArgumentException("Chave deve ser um número inteiro válido.");
            }
            deslocamento = Integer.parseInt(chaveStr.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Chave deve ser um número inteiro válido.");
        }

        // 2. Instanciar CriptoMensagem com os dados processados
        CriptoMensagem cripto = new CriptoMensagem(remetenteRaw, msgRaw, deslocamento);

        // 3. Obter o texto cifrado e o checksum do Model
        String textoCifrado = cripto.cifrar();
        int checksum = cripto.calcularChecksum();

        // 4. Formatar o pacote padrão
        String pacoteFinal = String.format("[%s] #%d -> %s", cripto.getRemetente(), checksum, textoCifrado);

        // 5. Adicionar o pacote à lista buffer
        bufferTransmissoes.add(pacoteFinal);

        // 6. Retornar o pacote formatado
        return pacoteFinal;
    }

    public int getTotalTransmissoes() {
        return bufferTransmissoes.size();
    }
}